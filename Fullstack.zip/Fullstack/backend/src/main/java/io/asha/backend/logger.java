package io.asha.backend;

public enum logger {
    ;

    public static void info(String string) {
    }

}
