
import React, { useCallback, useState } from "react";
import axios from "axios";
import Dropdown from 'react-dropdown';
import 'react-dropdown/style.css';
import DisplayBucketList from "./DisplayBucketList"
import { useDispatch, useSelector } from "react-redux";
import { setBucketLocation ,setBucketName} from "../redux/actions/bucketsActions";
// const accesstToken ="b179ea3b-8ab8-4ac1-9730-c27e6bf14442";
// const apiURL ="https://challenge.3fs.si/storage";
//  const authAxios = axios.create({
//      baseURL:apiURL,
//      headers:{
//          Authorization:`Bearer ${accesstToken}`
//      }
//  })
 const options = [
    'Kranj', 'Ljubljana'
  ];
  const defaultOption = options[0];



  const ShowinputElement = () => {


  const [hidden, setHidden] = useState(false);
  const [showInput,setShowInputs]=useState(false);
  const bucketLocation = useSelector((state) => state.bucketsDetails.bucketLocation);
  const bucketName = useSelector((state) => state.bucketsDetails.bucketName);
  const id = useSelector((state) => state.bucketsDetails.id);
  const dispatch = useDispatch();
  debugger
// const fetchData =useCallback(async ()=>{
//     try{
// const Result =  await authAxios.get (`/locations`)
// console.log('location',Result)
// SetLocationList(Result)
//     }
//     catch(err){
//         SetrequestError(err.message);
//     }
// })

  const showNewElements =(props)=>{
    // fetchData();
    setHidden(true);
    setShowInputs(true);
  }
 const SetSelectedLocation=(e)=>{
     debugger
    dispatch(setBucketLocation(e.value));
  }
  const setInputBucketName=(value)=>{
      debugger
    dispatch(setBucketName(value));
  }

const onTrigger=(e,id)=>{
    debugger
    if(id === 0){
      axios.post("http://localhost:8080/api/",{
        name:bucketName,
        location:bucketLocation,
      })
      .then((res)=>{
        this.componentDidMount();
      })
    }else{
      axios.put("http://localhost:8080/api/",{
        id:id,
        name:bucketName,
        location:bucketLocation,
      }).then(()=>{
        this.componentDidMount();
      })

    }

  }

  return (
    <div className="App">
      {!hidden &&  <button className="btn waves-effect waves-light right" type="submit" name="action" onClick ={showNewElements} >CreateBucket
         
        </button>}
        {showInput && 
        <div className="col s6">
        <form>
        <div className="input-field col s12">
          <label>Bucket Name*</label>
          <input  value="" type="text" id="autocomplete-input" value={bucketName} onChange={(e)=>setInputBucketName(e.target.value)}/>
        </div>
        <div className="input-field col s12">
          <span>Bucket Location*</span>
          <Dropdown options={options} onChange={(e)=>SetSelectedLocation(e)} value={bucketLocation} placeholder="Select an option" />;
        </div>
        <button className="btn waves-effect waves-light right" type="submit" name="action" onClick={(e)=>onTrigger(e,id)}>
          <i className="material-icons right">send</i>
        </button>
        </form>
      </div>
      
      }
      <DisplayBucketList/>
    </div>
  );
}
export default ShowinputElement;