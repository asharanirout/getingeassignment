import React, { useEffect, useCallback, useMemo } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { setBuckets} from "../redux/actions/bucketsActions";
const DisplayBucketList = () => {
  const buckets = useSelector((state) => state.bucketsDetails.buckets);
  const bucketLocation = useSelector((state) => state.bucketsDetails.bucketLocation);
  const bucketName = useSelector((state) => state.bucketsDetails.bucketName);
  const dispatch = useDispatch();


  const fetchProducts = async () => {
    const response = await axios
      .get("http://localhost:8080/api/")
      .catch((err) => {
        console.log("Err: ", err);
      });
    dispatch(setBuckets(response.data));
  };

  const deleteFile=async(id)=>{
    axios.delete(`http://localhost:8080/api/${id}`)
    .then(()=>{
      fetchProducts()
    })
  };
 
  useEffect(() => {
    fetchProducts();
  }, []);

  console.log("buckets :", buckets);
  console.log("bucketsLocation :", bucketLocation);
  console.log("bucketnmae :", bucketName);
  return (
    <div className="ui grid container">
         <div className="col s6">
      <table>
        <thead>
          <tr>
              <th>Name</th>
              <th>location</th>
              <th>Edit</th>
              <th>Delete</th>
          </tr>
        </thead>

        <tbody>
          {
            buckets.map(user=>
             
              <tr key={user.id}>
                
                <Link to={{pathname:`/bucket/${user.id}/${user.name}`,state:{bucketName:`${user.name}`}}}><td>{user.name}</td></Link>
                {/* <Link  to = {`/bucket/${user.id}/${user.name}`  state={{ from: 'occupation' }}}><td>{user.name}</td></Link> */}
                <td>{user.location}</td>
                <td>
                <button onClick={(e)=>this.edit(user.id)} class="btn waves-effect waves-light" type="submit" name="action">
                  <i class="material-icons">edit</i>
                </button>
                </td>
                <td>
                <button onClick={(e)=>deleteFile(user.id)} class="btn waves-effect waves-light" type="submit" name="action">
                  <i class="material-icons">delete</i>
                </button>
                </td>
          
              </tr>
              
              )
          }
          
        </tbody>
      </table>
      </div>
    </div>
  );
};

export default DisplayBucketList;
