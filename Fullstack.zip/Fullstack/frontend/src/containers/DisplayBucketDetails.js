import React, { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { useLocation } from 'react-router-dom';
import {useParams } from "react-router-dom";
import {
    TabContent, TabPane, Nav,
    NavItem, NavLink, Row, Col
} from 'reactstrap';
import classnames from 'classnames';
  
function DisplayBucketDetails() {
  
    // State for current active Tab
    const [currentActiveTab, setCurrentActiveTab] = useState('1');
    const { bucketName } = useParams();
    console.log("buctketName0",bucketName);
    // Toggle active state for Tab
    const toggle = tab => {
        if (currentActiveTab !== tab) setCurrentActiveTab(tab);
    }
    
  
    return (
        <div style={{
            display: 'block', width: 700, padding: 30
        }}>
         <h1>{bucketName}</h1>
         
            <Nav tabs>
                <NavItem>
                    <NavLink
                        className={classnames({
                            active:
                                currentActiveTab === '1'
                        })}
                        onClick={() => { toggle('1'); }}
                    >
                        Files
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink
                        className={classnames({
                            active:
                                currentActiveTab === '2'
                        })}
                        onClick={() => { toggle('2'); }}
                    >
                        Details
                    </NavLink>
                </NavItem>
               
            </Nav>
            <TabContent activeTab={currentActiveTab}>
                <TabPane tabId="1">
                    <Row>
                        <Col sm="12">
                            <table>
                            <thead>
                            <tr>
                            <th>Name</th>
                            <th>lastModified</th>
                            <th>Size</th>

                            </tr>
                            </thead>

                            {/* <tbody>
                            {
                            buckets.map(user=>

                            <tr key={user.id}>

                            <td>{user.name}</td>  
                            <td>{user.location}</td>
                            <td>
                            <button onClick={(e)=>this.edit(user.id)} class="btn waves-effect waves-light" type="submit" name="action">
                            <i class="material-icons">edit</i>
                            </button>
                            </td>
                            <td>
                            <button onClick={(e)=>deleteFile(user.id)} class="btn waves-effect waves-light" type="submit" name="action">
                            <i class="material-icons">delete</i>
                            </button>
                            </td>

                            </tr>

                            )
                            }

                            </tbody> */}
                            </table>
                        </Col>
                    </Row>
                </TabPane>
                <TabPane tabId="2">
                    <Row>
                        <Col sm="12">
                            <h5>Display Bucket name </h5>
                            <h5>Display Bucket Size </h5>
                            <h5>Display Delete Option </h5>
                        </Col>
                    </Row>
                </TabPane>
            
            </TabContent>
        </div >
    );
}
  
export default DisplayBucketDetails;