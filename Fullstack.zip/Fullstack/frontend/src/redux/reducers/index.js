import { combineReducers } from "redux";
import { productsReducer, selectedProductsReducer } from "./productsReducer";
import { bucketsReducer } from "./bucketsReducer";
const reducers = combineReducers({
  allProducts: productsReducer,
  product: selectedProductsReducer,
  bucketsDetails: bucketsReducer,
});
export default reducers;
