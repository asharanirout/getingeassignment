import { ActionTypes } from "../constants/action-types";
const intialState = {
  buckets: [],
  bucketName:'test',
  bucketLocation:'Kranj',
  id:0,
};

export const bucketsReducer = (state = intialState, { type, payload }) => {
  switch (type) {
    case ActionTypes.SET_BUCKETS:
      return { ...state, buckets: payload };
      case ActionTypes.SET_BUCKET_NAME:
          debugger
        return { ...state, bucketName: payload };
        case ActionTypes.SET_BUCKET_LOCATION:
            debugger
            return { ...state, bucketLocation: payload };
    default:
      return state;
  }
};


