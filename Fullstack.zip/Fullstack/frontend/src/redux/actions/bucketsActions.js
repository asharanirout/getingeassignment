import { ActionTypes } from "../constants/action-types";
//setBucketLocation ,setBucketName
export const setBuckets = (buckets) => {
    debugger
  return {
    type: ActionTypes.SET_BUCKETS,
    payload: buckets,
  };
};
export const setBucketLocation = (bucketLocation) => {
    debugger
  return {
    type: ActionTypes.SET_BUCKET_LOCATION,
    payload: bucketLocation,
  };
};
export const setBucketName = (bucketName) => {
    debugger
  return {
    type: ActionTypes.SET_BUCKET_NAME,
    payload: bucketName,
  };
};


