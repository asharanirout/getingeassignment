export const BUCKET_NAME = 'bucketName';
export const BUCKET_LOCATION = 'bucketLocation';