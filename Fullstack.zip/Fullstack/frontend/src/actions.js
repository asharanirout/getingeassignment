// export function addbucketName(description){
//     return  {
//         type:"bucketName",
//         payload:{
//           description:'valuwee'
//         }
//       }
// }
// export function addbucketLocation(description){
//     return  {
//         type:"bucketLocation",
//         payload:{
//           description:'valuwee'
//         }
//       }
// }
import * as actions from "./actionsType";
export const addbucketName = description =>({
         type:"bucketName",
                payload:{
                  description:'valuwee'
                }
              
    
})
export const addbucketLocation = description =>({
    type:"bucketLocation",
           payload:{
             description:'valuwee'
           }    

})