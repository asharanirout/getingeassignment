import * as actions from './actionsType';
let id=0;
let bucketName="";
let bucketLocation="";

export default function reducer(state=[],action){



    switch(action.type){
      case actions.BUCKET_NAME:return[
        ...state,
        {
            bucketName:action.payload.description,
        }
            ];
      case actions.BUCKET_LOCATION:return[
        ...state,
        {
            bucketLocation:action.payload,
        }
    ];
    default:
    return state;

    }
   
}